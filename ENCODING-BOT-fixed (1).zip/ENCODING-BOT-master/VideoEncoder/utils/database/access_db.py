

from ... import database, database_name
from .database import Database

db = Database(database, database_name)
